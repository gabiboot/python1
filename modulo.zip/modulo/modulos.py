def suma(a,b):
    #variable de control
    resultado = a+b
    return resultado
def resta(a,b):
    resultado = a-b
    return resultado
def multiplicacion(a,b):
    resultado = a*b
    return resultado

