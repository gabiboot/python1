import modulos

num1 = int(input("ingrese primer numero -> "))
num2 = int(input("ingrese segundo numero -> "))


#le pasamos los datos a la funcion
suma = modulos.suma(num1,num2)
print(f"El resultado de la suma es {suma}")

resta = modulos.resta(num1,num2)
print(f"El resultado de la resta es {resta}")

multiplicacion = modulos.multiplicacion(num1,num2)
print(f"El resultado de la multiplicacion es {multiplicacion}")