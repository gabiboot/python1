""""Crea un archivo llamado modulo_personalizado.py 
que contendrá la definición de la función es_par. Esta función 
debe tomar un número como argumento y devolver True si es par 
o False si es impar.

Solicita al usuario que ingrese un número.
Importa la función es_par desde modulo_personalizado.py en el programa principal.

Utiliza la función es_par para determinar si el 
número ingresado por el usuario es par o impar y muestra el resultado en pantalla."""


def es_par(num):
    return num % 2 == 0
