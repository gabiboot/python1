import modulopersonalizado


#pedir numer
num = int(input("por favor ingrese el numero -> "))

#llamar al modulo y la funcion
par = modulopersonalizado.es_par(num)

if par:
    print(f"{num} es un número par.")
else:
    print(f"{num} es un número impar.")